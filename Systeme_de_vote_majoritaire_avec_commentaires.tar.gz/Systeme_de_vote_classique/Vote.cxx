//Inclusion de différentes librairies
#include <iostream>
#include <iomanip>
#include <string>
#include<stdio.h>
#include<vector>
#include"Vote.h"

using namespace std;



vector <pair<string,int>> VoteClassique::tableau(const int VoteCSGO, const int VoteSFII, const int VoteCIV6, const int VoteMario){
    vector <pair<string,int>> tab_result;
    tab_result.push_back(make_pair("Counter Strike : Global Offensive",VoteCSGO));
    tab_result.push_back(make_pair("Street Fighter II",VoteSFII));
    tab_result.push_back(make_pair("Civilization VI",VoteCIV6));
    tab_result.push_back(make_pair("Mario Kart",VoteMario));
    for (unsigned i = 0; i < tab_result.size(); ++i)
    {
        for (unsigned k = i+1; k < tab_result.size(); ++k){
            if (tab_result[i].second > tab_result[k].second){
                swap (tab_result[i], tab_result[k]);
            }
        }
    }
    return tab_result;
}
