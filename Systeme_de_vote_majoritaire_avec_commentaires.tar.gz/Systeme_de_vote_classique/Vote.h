#ifndef VOTE_H
#define VOTE_H
#include<vector>
#include<string>

namespace VoteClassique
{
std::vector <std::pair<std::string,int>> tableau(const int VoteCSGO, const int VoteSFII, const int VoteCIV6, const int VoteMario);
}

#endif // VOTE_H
