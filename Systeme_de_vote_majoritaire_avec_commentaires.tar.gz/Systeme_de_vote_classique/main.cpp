﻿//Inclusion de différentes librairies
#include <iostream>
#include <iomanip>
#include <string>
#include<stdio.h>
#include<vector>
#include"Vote.h"

using namespace std;

// CSGO = 1
// SF2 = 2
// CIV6 = 3
// Mario = 4

int main()
{
    int VoteCSGO = 0;           //Initialisation du compteur de vote Counter Strike : Global Offensive
    int VoteSFII = 0;           //Initialisation du compteur de vote pour Street Fighter 2
    int VoteCIV6 = 0;           //Initialisation du compteur de vote pour Civilization VI
    int VoteMario = 0;          //Initialisation du compteur de vote pour Mario Kart
    int VoteB = 0;              //Initialisation d'un compteur pour les votes blancs
    string stock;               //Initialisation d'un chaîne de caractère stock
    int numLigne = 1;           //Initialisation d'un compteur numLigne permettant de compter le numéro de la ligne

    while (!cin.eof())          //boucle qui continue tant qu'elle n'arrive pas à la fin du fichier
    {
        getline(cin,stock);
        if (numLigne%3 == 0)            //Si le numéro de la ligne est un multiple de 3
        {
            if (stock[1] == '1')        //Si la valeur d'une ligne qui est un multiple de 3 est égale au caractère 1
                VoteCSGO +=1;           //Incrémenter la variable VoteCSGO de 1
            else if (stock[1] == '2')   //Sinon si la valeur d'une ligne qui est un multiple de 3 est égale au caractère 2
                VoteSFII +=1;           //Incrémenter la variable VoteSFII de 1
            else if (stock[1] == '3')   //Sinon si la valeur d'une ligne qui est un multiple de 3 est égale au caractère 3
                VoteCIV6 +=1;           //Incrémenter la variable VoteCIV6 de 1
            else if (stock[1] == '4')   //Sinon si la valeur d'une ligne qui est un multiple de 3 est égale au caractère 4
                VoteMario +=1;          //Incrémenter la variable VoteMario de 1
            else
                VoteB +=1;              //Sinon incrémenter de 1 la variable VotB qui représente les votes blancs.
        }

        numLigne +=1;
    }
    vector <pair<string,int>> tab = VoteClassique::tableau(VoteCSGO, VoteSFII, VoteCIV6, VoteMario);                //Initialise un tableau de vecteur avec les variable VoteCSGO, VoteSFII, VoteCIV6 et VoteMario
    cout << "Le grand gagnant du vote est: " << tab[3].first << " avec " << tab[3].second << " votes." << endl;     //Affiche le nombre de votes du 1er jeu
    cout << "Le deuxième est " << tab[2].first << " avec " << tab[2].second << " votes." << endl;                   //Affiche le nombre de votes du 2ème jeu
    cout << "Le troisième est " << tab[1].first << " avec " << tab[1].second << " votes." << endl;                  //Affiche le nombre de votes du 3ème jeu
    cout << "Le dernier est " << tab[0].first << " avec " << tab[0].second << " votes." << endl;                    //Affiche le nombre de votes du dernier jeu
    cout << "Il y a : " << VoteB << " votes blancs." << endl;                                                       //Affiche le nombre de votes blancs
    return 0;
}














