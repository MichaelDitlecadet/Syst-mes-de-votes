#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>    // std::sort
#include "election.h"

using namespace std;



void Election::initListeJeux1Tour (vector <Jeux> & ListeJeux)
{
    ListeJeux.resize(5);
    ListeJeux[0].name = "Blanc";
    ListeJeux[1].name = "Counter-Strike: Global Offensive";
    ListeJeux[2].name = "Street Fighter II";
    ListeJeux[3].name = "Civilisation VI";
    ListeJeux[4].name = "Mario Kart";
    for (unsigned i = 0; i < ListeJeux.size(); ++i)
    {
        ListeJeux[i].nbVotes = 0;
    }
}
void Election::initListeJeux2Tour (vector <Jeux> & ListeJeux1tour ,
                         vector <Jeux> & ListeJeux2tour)
{
    ListeJeux2tour.resize(3);
    ListeJeux2tour[0].name = "Blanc";
    ListeJeux2tour[1].name = ListeJeux1tour[0].name;
    if (ListeJeux1tour[1].name == "Blanc"){
        ListeJeux2tour[2].name = ListeJeux1tour[2].name;
    }
    else{
        ListeJeux2tour[2].name = ListeJeux1tour[1].name;
    }
    for (unsigned i = 0; i < ListeJeux2tour.size(); ++i)
    {
        ListeJeux2tour[i].nbVotes = 0;
    }
}
void Election::ajoutInfosDansVecteur(vector <InfoVotant> & ListeVotant)
{
    int ligneParcourue = 0;
    int i = 0;
    while (true)
    {
        string str;
        getline(cin,str);
        ++ligneParcourue;
        if (ligneParcourue%4 == 1)
        {
            ListeVotant.resize(ListeVotant.size()+1);
            ListeVotant[i].NOM = str;
        }
        if (ligneParcourue%4 == 2)
        {
            ListeVotant[i].PRENOM = str;
        }
        if (ligneParcourue%4 == 3)
        {
            ListeVotant[i].VOTEPREMIERTOUR = int(str[0])-48;
        }
        if (ligneParcourue%4 == 0)
        {
            ListeVotant[i].VOTESECONDTOUR = int(str[0])-48;
            ++i;
        }
        if (cin.eof ()) break;
    }
    ListeVotant.resize(ListeVotant.size()-1);
}
void Election::comptabilisationVotes(vector <InfoVotant> & ListeVotant,
                           vector <Jeux> & ListeJeux)
{
    if (ListeJeux.size() == 3)
    {
        for (unsigned i = 0 ; i < ListeVotant.size();++i)
        {
            ListeJeux[ListeVotant[i].VOTESECONDTOUR].nbVotes +=1;
        }
    }
    else
    {
        for (unsigned i = 0 ; i < ListeVotant.size();++i)
        {
            ListeJeux[ListeVotant[i].VOTEPREMIERTOUR].nbVotes -= -1;
        }
    }
}
bool Election::orderByNbVotes (const Jeux & J1, const Jeux & J2)
{
    return J1.nbVotes >= J2.nbVotes;
}
int Election::Sortie1tour (vector <InfoVotant> & ListeVotant, vector <Jeux> & ListeJeux)
{
    cout << endl <<"au premier tour le resultat est : " << endl << endl;
    unsigned ivoteblanc;
    for (unsigned i = 0;i<ListeJeux.size();++i){
        if (ListeJeux[i].name == "Blanc"){
            ivoteblanc = i;
        }
    }
    unsigned max = ListeVotant.size()-ListeJeux[ivoteblanc].nbVotes;
    int maj = 0;
    if (ListeJeux[0].name == "Blanc"){
        maj = 1;
        cout << "Le vote blanc est arrivé majoritaire, "
                "il vas falloir refaire des élections mais"
                " tout les candidats s'etant présenté a la premiere"
                " élection on interdiction de se representé";
    }
    else if (ListeJeux[0].nbVotes == ListeJeux[1].nbVotes
             == ListeJeux[2].nbVotes){
        maj = 1;
        cout << "3 candidats sont arrivé a égalité au premier"
                " tour il faudra donc organisé de nouvelle élection";
    }
    else if (ListeJeux[0].nbVotes >= max/2){
        maj = 1;
        cout << ListeJeux[0].name << " est arrivé premier avec"
                         " la majorité absolue il gagne donc les élections avec "
                           <<ListeJeux[0].nbVotes << "/" << max << "votes";
    }
    else{
        string place;
        unsigned cpt = 0;
        for (unsigned i = 0;i<ListeJeux.size();++i){
            if (not(i == ivoteblanc)){
                if (cpt == 0)
                    place = "premier";
                else if (cpt == 1)
                    place = "deuxieme";
                else if (cpt == 2)
                    place = "troisieme";
                else if (cpt == 3)
                    place = "quatrieme";
                cout << ListeJeux[i].name << " est arrivé " << place << " avec "
                     << ListeJeux[i].nbVotes << "/" << max << " votes" << endl;
                ++ cpt;
            }
        }
    }
    return maj;
}
void Election::Sortie2tour (vector <InfoVotant> & ListeVotant, vector <Jeux> & ListeJeux)
{
    cout << endl << "au deuxieme tour le resultat est : " << endl << endl;
    unsigned ivoteblanc;
    for (unsigned i = 0;i<ListeJeux.size();++i)
    {
        if (ListeJeux[i].name == "Blanc")
        {
            ivoteblanc = i;
        }
    }
    unsigned max = ListeVotant.size()-ListeJeux[ivoteblanc].nbVotes;
    if (ListeJeux[0].name == "Blanc"){
        cout << "Le vote blanc est arrivé majoritaire, il vas falloir "
                "refaire des élections mais tout les candidats s'etant "
                "présenté a la premiere élection on interdiction de se "
                "representé";
    }
    else if (ListeJeux[0].nbVotes == ListeJeux[1].nbVotes){
        cout << "les 2 candidats sont arrivé a égalité au second tour"
                " il faudra donc organisé de nouvelle élection";
    }
    else
    {
        cout << "le gagant des élections est "
             << ListeJeux[0].name
             << " avec " << ListeJeux[0].nbVotes << "/"
             << max << " votes " << ListeJeux[1].name
             << " est arrivé deuxieme avec " << ListeJeux[1].nbVotes
             << "/" << max << " votes ";
    }
}

