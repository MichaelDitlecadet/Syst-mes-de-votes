#ifndef ELECTION_H
#define ELECTION_H

#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>    // std::sort

struct Jeux
{
    //Struct contentant le nom et le nombre de votant des candidats
    std::string name;
    unsigned nbVotes;
};
struct InfoVotant
{
    //Struct contenant le nom, le prénom et le vote de l'élève/votant.
    std::string NOM;
    std::string PRENOM;
    unsigned VOTEPREMIERTOUR;
    unsigned VOTESECONDTOUR;
};


namespace Election

{

    void initListeJeux1Tour (std::vector <Jeux> & ListeJeux);
    /*
     *Cette fonction permet de crée la struct ListeJeux
     *et d'y mettre les nom des jeux et 0 a leur nombre de vote
    */

    void initListeJeux2Tour (std::vector <Jeux> & ListeJeux1tour ,
                             std::vector <Jeux> & ListeJeux2tour);
    /*
     *Cette fonction permet de crée la struct ListeJeux2
     *et d'y mettre les nom des jeux des gagants du premier tour
     *et 0 a leur nombre de vote
    */

    void ajoutInfosDansVecteur(std::vector <InfoVotant> & ListeVotant);
    /*
     * cette fonction permet de lire les infos d'un document externe et de
     * mettre les info dans une struct
    */

    void comptabilisationVotes(std::vector <InfoVotant> & ListeVotant,
                               std::vector<Jeux> & ListeJeux);
    /*
     * cette fonction permet de comptabilisé les voix de la struct
     * et d'augementer le nombre de vote de chaque participant
    */

    bool orderByNbVotes (const Jeux & J1, const Jeux & J2);
    /*
     * cette fonction sert a trié les resultats des votes
    */

    int Sortie1tour (std::vector <InfoVotant> & ListeVotant,
                     std::vector <Jeux> & ListeJeux);
    /*
     * cette fonction sert a afficher les resultats du premier tour
    */

    void Sortie2tour (std::vector <InfoVotant> & ListeVotant,
                      std::vector <Jeux> & ListeJeux);
    /*
     * cette fonction sert a afficher les
     * resultats du second tour si il y en a un
    */

}

#endif // ELECTION_H


