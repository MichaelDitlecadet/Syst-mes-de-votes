#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>    // std::sort

#include "election.h"

using namespace std;
using namespace Election;


int main()
{
    int maj;
    vector <Jeux> ListeJeux1Tour;
    initListeJeux1Tour(ListeJeux1Tour);
    vector <InfoVotant> ListeVotant;
    ajoutInfosDansVecteur(ListeVotant);
    comptabilisationVotes(ListeVotant,ListeJeux1Tour);
    sort (ListeJeux1Tour.begin(), ListeJeux1Tour.end(), orderByNbVotes);
    maj = Sortie1tour(ListeVotant,ListeJeux1Tour);
    if(not(maj == 1)){
        vector <Jeux> ListeJeux2Tour;
        initListeJeux2Tour(ListeJeux1Tour,ListeJeux2Tour);
        comptabilisationVotes(ListeVotant,ListeJeux2Tour);
        sort (ListeJeux2Tour.begin(), ListeJeux2Tour.end(), orderByNbVotes);
        Sortie2tour(ListeVotant,ListeJeux2Tour);
    }
}
