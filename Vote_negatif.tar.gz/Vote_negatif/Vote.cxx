#include <vector>
#include <iostream>


#include "Vote.h"

using namespace std;


/*Cette fonction sert à trier les valeurs du vote obtenues
 * dans le programme principal. Il renvoie ensuite un tableau trié
 * dans l'ordre croissant qui contient un tuple, lui même composé du nom du jeu
 *  sous forme de string et du nombre de votes du jeu.*/
vector<pair<string,int>> Vote_negatif::Tri_result(const int CSGO,
                                                  const int MK,
                                                  const int CIV, const int SF2)
{
    vector<pair<string,int>> tab_result;
    tab_result.push_back(make_pair("Counter Strike",CSGO));
    tab_result.push_back(make_pair("MarioKart",MK));
    tab_result.push_back(make_pair("Civilisation VI",CIV));
    tab_result.push_back(make_pair("Street Fighter 2",SF2));
    pair<string,int> temp ;
    for (unsigned i = 0; i < tab_result.size(); ++i)
    {
        for (unsigned k = i+1; k < tab_result.size(); ++k){
            if (tab_result[i].second > tab_result[k].second){
                temp = tab_result[i];
                tab_result[i] = tab_result[k];
                tab_result[k] = temp;
            }
        }
    }
    return tab_result;
}
