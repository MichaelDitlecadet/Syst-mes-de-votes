#ifndef VOTE_H
#define VOTE_H
#include <string>
#include <vector>

namespace Vote_negatif
{

/*Cette fonction sert à trier les valeurs du vote obtenues
 * dans le programme principal. Il renvoie ensuite un tableau trié
 * dans l'ordre croissant qui contient un tuple, lui même composé du nom du jeu
 *  sous forme de string et du nombre de votes du jeu.*/

std::vector <std::pair<std::string,int>> Tri_result(const int CSGO, const int MK, const int CIV, const int SF2);

} //Vote_négatif

#endif // VOTE_H
