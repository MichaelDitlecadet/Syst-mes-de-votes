#include <vector>
#include <iostream>
#include "Vote.h"

using namespace std;
using namespace Vote_negatif;

/* Organisation des votes dans le fichier :
 * Counter Strike = 1
 * Street Fighter II = 2
 * Civilisation VI = 3
 * Mario Kart = 4
 * Vote blanc = 0
 * Vote négatif = - (exemple pour csgo négatif = -a)
 */

int main(){
    /* On initialise toute les variables que l'on aura besoin tout au long
     * du programme.*/
    unsigned num_ligne = 1;
    int CSGO = 0;
    int MK = 0;
    int CIV = 0;
    int SF2 = 0;
    int vote_blanc = 0;
    string ligne_vote;
    while(cin.eof()!=true) /*On parcourt le fichier ligne par ligne jusqu'à la
                            *fin du fichier.*/
    {
        getline(cin , ligne_vote); //On récupère les lignes du fichier entrant.
        if(num_ligne % 3 == 0) /* On n'utilise que les lignes qui
                                *contiennent les votes.*/
        {
            /*On détermine quel est le vote ici puis on ajoute/soustrait à la
             * bonne variable selon le vote.*/
            if (ligne_vote[1]!= '-' ) // Si c'est un vote contre.
            {
                if (ligne_vote[1]== '0')
                    vote_blanc+=1;
                if (ligne_vote[1]== '1')
                    CSGO+=1;
                if (ligne_vote[1]== '2')
                    SF2+=1;
                if (ligne_vote[1]=='3')
                    CIV+=1;
                if (ligne_vote[1]=='4')
                    MK+=1;
            }
            else if (ligne_vote[1] == '-') //Si c'est un vote pour.
            {
                if(ligne_vote[3]== '1')
                    CSGO = CSGO -1;
                if (ligne_vote[3]== '2')
                    SF2 = SF2 - 1;
                if (ligne_vote[3]== '3')
                    CIV = CIV - 1;
                if (ligne_vote[3]== '4')
                    MK = MK - 1;
            }
        }
        num_ligne += 1;
    }
    /*On tri ensuite les variables dans un ordre croissant
     * pour pouvoir les classer ensuite.
     * Enfin, on écrit dans le fichier sortant les résultats du vote.*/
    vector <pair<string,int>> tab_result = Tri_result(CSGO,MK,CIV,SF2);
    cout << "Le premier est " << tab_result[3].first << " avec " << tab_result[3].second << endl;
    cout << "Le deuxième est " << tab_result[2].first << " avec " << tab_result[2].second << endl;
    cout << "Le troisième est " << tab_result[1].first << " avec " << tab_result[1].second << endl;
    cout << "Le quatrième est " << tab_result[0].first << " avec " << tab_result[0].second <<endl;
    cout << "Il y a " << vote_blanc << " votes blancs en tout." << endl;
    return 0;
}
